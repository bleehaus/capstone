# rivescript-sublimetext
[Rivescript](https://www.rivescript.com/) syntax definition for Sublime Text
